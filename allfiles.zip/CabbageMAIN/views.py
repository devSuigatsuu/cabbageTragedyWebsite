from django.http import HttpResponse
from django.shortcuts import render
from .forms import ArticlesForm
from .models import Article

def main_page(request):
    articles = Article.objects.all().order_by('-date')
    return render(request, 'index.html', {'articles': articles})

def about_us_page(request):
    return render(request, 'about_us.html')