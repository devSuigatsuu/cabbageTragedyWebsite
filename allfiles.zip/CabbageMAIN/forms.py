from .models import Article
from django.forms import ModelForm

class ArticlesForm(ModelForm):
    class Meta:
        model = Article
        fields = ['username', 'title', 'anons', 'full_text', 'date']